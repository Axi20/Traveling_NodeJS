const express = require('express');
const app = express();
const ejs = require('ejs');

// Middleware 
app.set('view engine', 'ejs');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.get('/', (req, res) => {
    res.render('index');
});
app.get('/rendel', (req, res, next) => {
    res.render('rendeles');
});



app.listen(3001, () => {
    console.log(`A szerver fut a következő porton http://localhost:3001 `);
});